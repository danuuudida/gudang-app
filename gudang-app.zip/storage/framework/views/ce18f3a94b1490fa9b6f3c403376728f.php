<img src="<?php echo e(asset('img/furiexhitam.png')); ?>" alt="Logo" class="h-20" >
<?php /**PATH C:\laragon\www\gudang-app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>