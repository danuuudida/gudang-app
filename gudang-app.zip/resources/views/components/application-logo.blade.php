<img src="{{ asset('img/furiexhitam.png') }}" alt="Logo" class="h-20" >
